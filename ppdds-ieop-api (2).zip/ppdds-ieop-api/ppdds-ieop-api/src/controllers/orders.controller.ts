import { Request, Response } from "express";
import primavera from "../services/primavera.service";
import fs from "fs";


const getAll = async (_: Request, res: Response) => {
  const token = res.locals.token;

  const response = await primavera.get("/sales/orders", token);
  
  return res.json(response);
};

const getCustomers = async (_: Request, res: Response) => {
  const token = res.locals.token;

  try {
    const response = await primavera.get("/salesCore/customerParties", token);
    return res.json(response);
  } catch (error) {
    console.log("Errou");
    console.log(error);
  }
};

const getSalesItems = async (_: Request, res: Response) => {
  const token = res.locals.token;

  try {
    const response = await primavera.get("/salesCore/salesItems", token);

    // Mapeia os dados da resposta para o formato desejado
    const mappedItems = response.map((item: any) => ({
      idPRoduto:item.baseEntityId,
      nomeProduto: item.itemKey,
      marcaProduto: item.brand,
      precoProduto: item.priceListLines.length > 0 ? parseFloat(item.priceListLines[0].priceAmount.amount) : null,
   
    }));

    // Cria um arquivo JSON com os dados mapeados
    const jsonData = JSON.stringify(mappedItems, null, 2);
    fs.writeFileSync("salesItems.json", jsonData);

    // Retorna a resposta com os dados mapeados
    return res.json(mappedItems);
  } catch (error) {
    console.log("Erro ao buscar itens de venda:");
    console.log(error);
    return res.status(500).json({ error: "Failed to fetch sales items" });
  }
};

const getQuotations = async (_: Request, res: Response) => {
  const token = res.locals.token;

  try {

    const response = await primavera.get("/sales/quotations", token);
    return res.json(response);
  } catch (error) {
    console.log("Errou");
    console.log(error);
  }

};

const createInvoice = async (req: Request, res: Response) => {
  const token = res.locals.token;
  const invoiceData = req.body;

  console.log("invoice:", invoiceData);

  try {
    // Certifique-se de que os dados necessários para criar a fatura estão presentes
    if (!invoiceData.documentLines || invoiceData.documentLines.length === 0) {
      return res.status(400).json({ error: "Faltam dados necessários para a criação da fatura" });
    }

    // Mapear a estrutura de dados necessária para a criação da fatura
    const invoicePayload = {
      buyerCustomerParty: invoiceData.buyerCustomerParty,
      serie: 2023,
      documentDate: new Date().toISOString(),
      postingDate: new Date().toISOString(),
      documentLines: invoiceData.documentLines.map((line: any) => {
        const mappedLine = {
          salesItem: line.salesItem,
          unitPrice: {
            amount: line.amount
          }
        };
        console.log("Mapped Line:", mappedLine);
        return mappedLine;
      })
    };
    console.log("linhas: ", invoicePayload);

    // Faça a solicitação POST para criar a fatura no Primavera
    const response = await primavera.post("/billing/invoices", invoicePayload, token);

    // Retorna a resposta da criação da fatura
    return res.json(response);
  } catch (error) {
    console.log("Erro ao criar fatura:", error);
    console.log(error);
    return res.status(500).json({ error: "Falha ao criar a fatura" });
  }
};

export default { getAll, getCustomers, getSalesItems, getQuotations, createInvoice};
