import axios from "axios";
import { PRIMAVERA_API_URL } from "../config";

const get = (endpoint: string, token: string) => {
  return axios
    .get(`${PRIMAVERA_API_URL}${endpoint}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then((res) => res.data);
};

const post = (endpoint: string, data: any, token: string) => {
  return axios
    .post(`${PRIMAVERA_API_URL}${endpoint}`, data, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    })
    .then((res) => res.data)
    .catch((error) => {
      // Adicionar tratamento de erros, como logs ou lançamento de exceção
      console.error("Erro na requisição POST", error);
      throw error;
    });
};

export default { get, post };

