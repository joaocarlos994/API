import Router from "express";
import controller from "../controllers/orders.controller";

const router = Router();

router.get("/", controller.getAll);
router.get("/customerParties", controller.getCustomers);
router.get("/salesItems", controller.getSalesItems);
router.get("/quotations", controller.getQuotations);

router.post('/invoices', controller.createInvoice);


export default router;
